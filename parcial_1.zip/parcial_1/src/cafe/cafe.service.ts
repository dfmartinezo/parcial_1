import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { BusinessError, BusinessLogicException } from '../shared/errors/business-errors';
import { Repository } from 'typeorm';
import { CafeEntity } from './cafe.entity';

@Injectable()
export class CafeService {
    constructor(
        @InjectRepository(CafeEntity)
        private readonly cafeRepository: Repository<CafeEntity>
    ){}


    //Crear
    async create(cafe: CafeEntity): Promise<CafeEntity> {

        const precioNuevo = cafe.precio

        if(precioNuevo < 0 )
            throw new BusinessLogicException("El precio debe ser positivo", BusinessError.PRECONDITION_FAILED);
        
        return await this.cafeRepository.save(cafe);
    }
 
}
