import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TypeOrmTestingConfig } from '../shared/testing-utils/typeorm-testing-config';
import { CafeEntity } from './cafe.entity';
import { CafeService } from './cafe.service';

import { faker } from '@faker-js/faker';


describe('CafeService', () => {
 let service: CafeService;
 let repository: Repository<CafeEntity>;
 let listatiendas: CafeEntity[];


 beforeEach(async () => {
   const module: TestingModule = await Test.createTestingModule({
     imports: [...TypeOrmTestingConfig()],
     providers: [CafeService],
   }).compile();

   service = module.get<CafeService>(CafeService);
   repository = module.get<Repository<CafeEntity>>(getRepositoryToken(CafeEntity));
   await seedDatabase();

 });

 const seedDatabase = async () => {
  repository.clear();
  listatiendas = [];
  for(let i = 0; i < 5; i++){
      const cafe: CafeEntity = await repository.save({
      id: parseInt(faker.random.numeric()),
      nombre: faker.lorem.sentence(), 
      descripcion: faker.lorem.sentence(), 
      precio: i+12930
    })
      listatiendas.push(cafe);
  }
}
  
 it('should be defined', () => {
   expect(service).toBeDefined();
 });

 
it('create should return a new cafe', async () => {
  const cafe: CafeEntity = {
    id: parseInt(faker.random.numeric()),
    nombre: faker.lorem.sentence(), 
    descripcion: faker.lorem.sentence(),
    precio: parseInt(faker.random.numeric()), 
    tiendas: []
  }

  const newcafe: CafeEntity = await service.create(cafe);
  expect(newcafe).not.toBeNull();

  const storedcafe: CafeEntity = await repository.findOne({where: {id: newcafe.id}})
  expect(storedcafe).not.toBeNull();
  expect(storedcafe.nombre).toEqual(newcafe.nombre)
  expect(storedcafe.descripcion).toEqual(newcafe.descripcion)
  expect(storedcafe.precio).toEqual(newcafe.precio)

});

it('create should throw an exception for invalid phone number', async () => {
    const cafe: CafeEntity = {
    id: parseInt(faker.random.numeric()),
    nombre: faker.lorem.sentence(), 
    descripcion: faker.lorem.sentence(), 
    precio: -12000,
    tiendas: []
  }

  await expect(() => service.create(cafe)).rejects.toHaveProperty("message", "El precio debe ser positivo")
});

});