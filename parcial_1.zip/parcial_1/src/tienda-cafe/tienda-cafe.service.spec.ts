
import { Test, TestingModule } from '@nestjs/testing';
import { TypeOrmTestingConfig } from '../shared/testing-utils/typeorm-testing-config';
import { Repository } from 'typeorm';
import { TiendaCafeService } from './tienda-cafe.service';
import { faker } from '@faker-js/faker';
import { TiendaEntity } from '../tienda/tienda.entity';
import { CafeEntity } from '../cafe/cafe.entity';
import { getRepositoryToken } from '@nestjs/typeorm';


describe('TiendaCafeService', () => {
  let service: TiendaCafeService;
  let tiendaRepository: Repository<TiendaEntity>;
  let cafeRepository: Repository<CafeEntity>;
  let tienda: TiendaEntity;
  let cafeList : CafeEntity[];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [...TypeOrmTestingConfig()],
      providers: [TiendaCafeService],
    }).compile();

    service = module.get<TiendaCafeService>(TiendaCafeService);
    tiendaRepository = module.get<Repository<TiendaEntity>>(getRepositoryToken(TiendaEntity));
    cafeRepository = module.get<Repository<CafeEntity>>(getRepositoryToken(CafeEntity));
    await seedDatabase();
  });

  const seedDatabase = async () => {
    cafeRepository.clear();
    tiendaRepository.clear();
 
    cafeList = [];
    for(let i = 0; i < 5; i++){
      const cafe: CafeEntity = await cafeRepository.save({
        id: i,
        nombre: faker.lorem.sentence(), 
        descripcion: faker.lorem.sentence(), 
        precio: i+12930
    })
    cafeList.push(cafe);
  }
 
    tienda = await tiendaRepository.save({
      id: 100,
      nombre: faker.lorem.sentence(), 
      direccion: faker.lorem.sentence(), 
      telefono: "3156739489",
      cafes: cafeList
    })
  }

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('addCafeToTienda should add an cafe to a tienda', async () => {
    const newcafe: CafeEntity = await cafeRepository.save({
      id: parseInt(faker.random.numeric()),
      nombre: faker.lorem.sentence(), 
      descripcion: faker.lorem.sentence(), 
      precio: 12000
    });
 
    const newtienda: TiendaEntity = await tiendaRepository.save({
      id: parseInt(faker.random.numeric()),
      nombre: faker.lorem.sentence(), 
      direccion: faker.lorem.sentence(), 
      telefono: "3156739215"
    })
 
    const result: TiendaEntity = await service.addCafeToTienda(newcafe.id, newtienda.id);
   
    expect(result.cafes.length).toBe(1);
    expect(result.cafes[0]).not.toBeNull();
    expect(result.cafes[0].nombre).toBe(newcafe.nombre)
    expect(result.cafes[0].descripcion).toBe(newcafe.descripcion)
    expect(result.cafes[0].precio).toBe(newcafe.precio)
  });

  it('addCafeToTienda should thrown exception for an invalid cafe', async () => {
    const newtienda: TiendaEntity = await tiendaRepository.save({
      id: parseInt(faker.random.numeric()),
      nombre: faker.lorem.sentence(), 
      direccion: faker.lorem.sentence(), 
      telefono: "3156739215"
    })
 
    await expect(() => service.addCafeToTienda(678676, newtienda.id)).rejects.toHaveProperty("message", "El cafe con el id dado no fue encontrado");
  });

  it('addCafeToTienda should throw an exception for an invalid tienda', async () => {
    const newcafe: CafeEntity = await cafeRepository.save({
      id: parseInt(faker.random.numeric()),
      nombre: faker.lorem.sentence(), 
      descripcion: faker.lorem.sentence(), 
      precio: 12000
    });
 
    await expect(() => service.addCafeToTienda(newcafe.id, 0)).rejects.toHaveProperty("message", "La tienda con el id dado no fue encontrado");
  });

});