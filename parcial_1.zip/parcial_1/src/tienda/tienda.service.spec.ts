import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TypeOrmTestingConfig } from '../shared/testing-utils/typeorm-testing-config';
import { TiendaEntity } from './tienda.entity';
import { TiendaService } from './tienda.service';

import { faker } from '@faker-js/faker';


describe('TiendaService', () => {
 let service: TiendaService;
 let repository: Repository<TiendaEntity>;
 let listatiendas: TiendaEntity[];


 beforeEach(async () => {
   const module: TestingModule = await Test.createTestingModule({
     imports: [...TypeOrmTestingConfig()],
     providers: [TiendaService],
   }).compile();

   service = module.get<TiendaService>(TiendaService);
   repository = module.get<Repository<TiendaEntity>>(getRepositoryToken(TiendaEntity));
   await seedDatabase();

 });

 const seedDatabase = async () => {
  repository.clear();
  listatiendas = [];
  for(let i = 0; i < 5; i++){
      const tienda: TiendaEntity = await repository.save({
      id: parseInt(faker.random.numeric()),
      nombre: faker.lorem.sentence(), 
      direccion: faker.lorem.sentence(), 
      telefono: "315673948"+i
    })
      listatiendas.push(tienda);
  }
}
  
 it('should be defined', () => {
   expect(service).toBeDefined();
 });

 
it('create should return a new tienda', async () => {
  const tienda: TiendaEntity = {
    id: parseInt(faker.random.numeric()),
    nombre: faker.lorem.sentence(), 
    direccion: faker.lorem.sentence(),
    telefono: "3156739481", 
    cafes: []
  }

  const newtienda: TiendaEntity = await service.create(tienda);
  expect(newtienda).not.toBeNull();

  const storedtienda: TiendaEntity = await repository.findOne({where: {id: newtienda.id}})
  expect(storedtienda).not.toBeNull();
  expect(storedtienda.nombre).toEqual(newtienda.nombre)
  expect(storedtienda.direccion).toEqual(newtienda.direccion)
  expect(storedtienda.telefono).toEqual(newtienda.telefono)

});

it('create should throw an exception for invalid phone number', async () => {
    const tienda: TiendaEntity = {
    id: parseInt(faker.random.numeric()),
    nombre: faker.lorem.sentence(), 
    direccion: faker.lorem.sentence(), 
    telefono: faker.lorem.sentence(), 
    cafes: []
  }

  await expect(() => service.create(tienda)).rejects.toHaveProperty("message", "El telefono debe tener 10 caracteres")
});

});